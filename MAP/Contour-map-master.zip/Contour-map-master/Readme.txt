Trying to testore a broken contour map.

In "read output file," after changing file path in the function open() to your targeting csv file, compile it to make it work.

If you don't wish to display the contour map, comment "show graph."
If you don't wish to display the error, comment "show error."
