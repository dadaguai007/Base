# MAPClassifier
a Machine Learning algorithm of a MAP Classifier (maximum a posteriori)
