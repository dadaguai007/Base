# ML_lab_assignment_2
contains IPYNB file.. contains MLE (Maximum Likelihood Estimation) and MAP (Maximum a Posteriori)
