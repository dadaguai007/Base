# Convolutional-coding-and-viterbi-decoding
A project about implementing the convolutional encoder and  hard/soft decoder in digital communication course in 2022  
