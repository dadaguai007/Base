# TCM-8PSK
在matlab下的基于Trellis Code的8psk调制解调仿真，包括软/硬判决
