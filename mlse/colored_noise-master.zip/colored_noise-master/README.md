# Maximum Likelihood detection in colored noise using a predictive Viterbi algorithm

References: 

See Section 2.7 in the book "Digital Communications and Signal Processing" by K Vasudevan
