# Decoding convolutional codes using the Viterbi algorithm
# I can say that Python is slower than MATLAB and very much slower than C language
