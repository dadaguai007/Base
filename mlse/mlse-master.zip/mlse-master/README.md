# Maximum likelihood sequence estimation (MLSE) using the Viterbi algorithm

References: 

See Section 5.2 in the book "Digital Communications and Signal Processing" by K Vasudevan
